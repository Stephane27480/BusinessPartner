package Alien::Foo1;

use strict;
use warnings;
use base qw( Alien::Base );

1;
