=====================
SDAM Monitoring Tests
=====================

The YAML and JSON files in this directory tree are platform-independent tests
that drivers can use to prove their conformance to the SDAM Monitoring spec.

Format
------

The format of the tests follows the standard SDAM test and should be able to leverage
the existing test runner in each language for the SDAM tests.
